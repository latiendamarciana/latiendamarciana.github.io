---
heading: "p xs bold"
---

{% for item in site.data.basic-typography-styles %}{{ item.paragraphs-text-1 }}{% endfor %}
{: .p-xs .bold }

{% for item in site.data.basic-typography-styles %}{{ item.paragraphs-text-2 }}{% endfor %}
{: .p-xs .bold }