---
# --- Identificación ---
layout: basic-index
title: "Estilos y componentes básicos para Figma y Jekyll"
name: "Inicio"
heading: "Estilos y componentes básicos para Figma y Jekyll"
permalink: /

# --- SEO / Metadatos ---
description: "Base de estilos y componentes para Figma y Jekyll. Tipografía, colores, botones, imágenes responsive y componentes listos para wireframes y desarrollo."
author: "fluorescente.design"
date: 2026-02-09
tags: ["Figma", "Jekyll", "wireframes", "componentes", "CSS", "responsive"]
keywords: "Figma estilos, Jekyll componentes, wireframes responsive, diseño desarrollo"
image: "assets/images/basic/estilos-y-componentes-basicos-card.png"

# --- Hero / Imagen principal ---
hero-image-xs: "/assets/images/basic/hero-image-xs-lg.svg"
hero-image-sm: "/assets/images/basic/hero-image-sm.svg"
hero-image-lg: "/assets/images/basic/hero-image-xs-lg.svg"
hero-image-src: "/assets/images/basic/hero-image-xs-lg.svg"
hero-image-alt: "Muestra de estilos tipográficos, colores, botones, una tarjeta, una imágen de proporción 3:2, y un paginador"

# --- Footer ---
footer-text: '**Diseño y desarrollo:** [**fluorescente.design**](https://www.fluorescente.design){:target="_blank"} Si estos recursos te parecen útiles, puedes dejar un aporte en Ko-fi. Gracias <span class="icon icon-heart-fill"></span>'

# -- Links ---
figma-link: "https://github.com/fluorescente/estilos-y-componentes-basicos-para-figma-y-jekyll/raw/refs/heads/main/assets/figma/Estilos-y-componentes-b%C3%A1sicos.fig"
jekyll-link: "https://github.com/fluorescente/estilos-y-componentes-basicos-para-figma-y-jekyll/raw/refs/heads/main/assets/jekyll-zip/estilos-y-componentes-b-sicos-para-figma-y-jekyll-main.zip"
github-link: "https://github.com/fluorescente/estilos-y-componentes-basicos-para-figma-y-jekyll.git"

---

Una base para wireframes, diseño y desarrollo. Incluye estilos tipográficos, colores neutros, botones, enlaces, imágenes en diferentes proporciones, íconos, y algunos componentes.